// $('.body-cards .card-body').click(function(){
    
//     $(this).find('.teste').addClass('collapse');
    
//     $(this).find('.container-btn').click(function(){
//         $(this).toggleClass('active');
//         $(this).next('.teste').collapse('toggle');
//     });    
// });
